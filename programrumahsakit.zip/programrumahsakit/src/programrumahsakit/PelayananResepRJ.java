/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programrumahsakit;

import javax.swing.table.DefaultTableModel;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.awt.HeadlessException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.awt.HeadlessException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/**
 *
 * @author Danz
 */
public class PelayananResepRJ extends javax.swing.JFrame {

    private Connection Con;
    private Statement stm;
    private ResultSet rs;
    /**
     * Creates new form PelayananResepRJ
     */
    public PelayananResepRJ() {
        initComponents();
        setLocationRelativeTo(this);
        aktif(false);
        setTombol(true);
        tampil_tindakan();
        tampil_obat();
        tampil();
        tampilkan_data();
        this.setLocationRelativeTo(null);
    try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
        Statement statement = (Statement) koneksi.createStatement();
        String sql = "SELECT * from rajal";      
        rs = stm.executeQuery(sql);                               
        
        while(rs.next()){
            int idpasien = Integer.parseInt(rs.getString("id_ugd"));
                Cbnama.addItem( rs.getString("id_pasien"));                            
        }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
         try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
        Statement statement = (Statement) koneksi.createStatement();
        String sql = "SELECT * from tindakan";      
        rs = stm.executeQuery(sql);                               
        
        while(rs.next()){
            int idpasien = Integer.parseInt(rs.getString("id_tindakan"));
                Cbtindakan.addItem( rs.getString("jenis_tindakan"));                            
        }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
         {
             try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
        Statement statement = (Statement) koneksi.createStatement();
        String sql = "SELECT * from obat";      
        rs = stm.executeQuery(sql);                               
        
        while(rs.next()){
            int idpasien = Integer.parseInt(rs.getString("id_obat"));
                Cbobat.addItem( rs.getString("nama_obat"));                            
        }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
             
}
    
    
    }
    
    {
        
    }
    
    public void tampil (){
        try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
        Statement statement = (Statement) koneksi.createStatement();
        String sql = "SELECT tgl_lahir, id_dokter FROM rajal WHERE id_pasien='"+Cbnama.getSelectedItem()+"'";  
        rs = statement.executeQuery(sql);
        
        while(rs.next()){
            Object[] ob = new Object[3];
            ob[0]=  rs.getString(1);
            ob[1]= rs.getString(2);
            
            
            LBtgllahir.setText((String)ob[0]);
            LBdokter.setText((String)ob[1]);
            
        }
        rs.close(); stm.close();
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } 
        
}  public void tampil_tindakan (){
        try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
        Statement statement = (Statement) koneksi.createStatement();
        String sql = "SELECT harga_tindakan FROM tindakan WHERE jenis_tindakan='"+Cbtindakan.getSelectedItem()+"'";  
        rs = statement.executeQuery(sql);
        
        while(rs.next()){
            Object[] ob = new Object[2];
            ob[0]=  rs.getString(1);
            
            
            
            LBtariftindakan.setText((String)ob[0]);
            
            
        }
        rs.close(); stm.close();
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } 
        }  public void tampil_obat (){
        try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
        Statement statement = (Statement) koneksi.createStatement();
        String sql = "SELECT harga_obat FROM obat WHERE nama_obat='"+Cbobat.getSelectedItem()+"'";  
        rs = statement.executeQuery(sql);
        
        while(rs.next()){
            Object[] ob = new Object[2];
            ob[0]=  rs.getString(1);
            
            
            
            LBhargaobat.setText((String)ob[0]);
            
            
        }
        rs.close(); stm.close();
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } 

        }  
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        PanelRJ = new javax.swing.JPanel();
        TFregis = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        Btncari = new javax.swing.JButton();
        Cbnama = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        LBtgllahir = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        LBhargaobat = new javax.swing.JLabel();
        TFqty = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        LBdokter = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        Cbtindakan = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        LBtariftindakan = new javax.swing.JLabel();
        Cbobat = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        TFinputresep = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        LBpoli = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        Btnkeluar = new javax.swing.JButton();
        Btnedit = new javax.swing.JButton();
        Btnsimpan = new javax.swing.JButton();
        Btntambah = new javax.swing.JButton();
        Btnhapus = new javax.swing.JButton();
        Btnbatal = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        jLabel10.setText("No Resep");

        Btncari.setText("Cari");
        Btncari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtncariActionPerformed(evt);
            }
        });

        Cbnama.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-Pilih-" }));
        Cbnama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CbnamaActionPerformed(evt);
            }
        });

        jLabel1.setText("Nama Pasien");

        LBtgllahir.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        LBtgllahir.setText("-------------");

        jLabel4.setText("Tgl lahir");

        LBhargaobat.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        LBhargaobat.setText("-------------");

        TFqty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TFqtyActionPerformed(evt);
            }
        });

        jLabel15.setText("Qty");

        LBdokter.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        LBdokter.setText("-------------");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Rp,-");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("Rp,-");

        jLabel11.setText("Dokter");

        Cbtindakan.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-Pilih-" }));
        Cbtindakan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CbtindakanActionPerformed(evt);
            }
        });

        jLabel5.setText("Tarif");

        LBtariftindakan.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        LBtariftindakan.setText("-------------");

        Cbobat.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-Pilih-" }));
        Cbobat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CbobatActionPerformed(evt);
            }
        });

        jLabel3.setText("Tindakan");

        jLabel13.setText("Obat");

        jLabel14.setText("Harga");

        jButton3.setText("Hari Ini");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel7.setText("Tanggal Input Resep");

        LBpoli.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        LBpoli.setText("-------------");

        jLabel17.setText("Poli");

        javax.swing.GroupLayout PanelRJLayout = new javax.swing.GroupLayout(PanelRJ);
        PanelRJ.setLayout(PanelRJLayout);
        PanelRJLayout.setHorizontalGroup(
            PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelRJLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelRJLayout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(TFinputresep, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3))
                    .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelRJLayout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(Cbtindakan, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(PanelRJLayout.createSequentialGroup()
                                    .addComponent(jLabel8)
                                    .addGap(18, 18, 18)
                                    .addComponent(LBtariftindakan)))
                            .addGap(63, 63, 63))
                        .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(PanelRJLayout.createSequentialGroup()
                                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel3))
                                .addGap(216, 216, 216)
                                .addComponent(jLabel15)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(TFqty, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(PanelRJLayout.createSequentialGroup()
                                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelRJLayout.createSequentialGroup()
                                        .addComponent(jLabel13)
                                        .addGap(59, 59, 59))
                                    .addGroup(PanelRJLayout.createSequentialGroup()
                                        .addComponent(jLabel14)
                                        .addGap(54, 54, 54)))
                                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(PanelRJLayout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addGap(18, 18, 18)
                                        .addComponent(LBhargaobat))
                                    .addComponent(Cbobat, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(62, 62, 62))))
                    .addGroup(PanelRJLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(Cbnama, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelRJLayout.createSequentialGroup()
                        .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel17)
                            .addComponent(jLabel11)
                            .addComponent(jLabel4))
                        .addGap(34, 34, 34)
                        .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(LBtgllahir)
                                .addComponent(LBdokter))
                            .addComponent(LBpoli, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap(32, Short.MAX_VALUE))
            .addGroup(PanelRJLayout.createSequentialGroup()
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(TFregis, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(Btncari)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        PanelRJLayout.setVerticalGroup(
            PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelRJLayout.createSequentialGroup()
                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(TFregis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Btncari))
                .addGap(18, 18, 18)
                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Cbnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(LBpoli, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(LBtgllahir, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LBdokter)
                    .addComponent(jLabel11))
                .addGap(18, 18, 18)
                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Cbtindakan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(LBtariftindakan)
                        .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING)))
                .addGap(12, 12, 12)
                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(Cbobat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TFqty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addGap(13, 13, 13)
                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addGroup(PanelRJLayout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(LBhargaobat))
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addGroup(PanelRJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TFinputresep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jButton3))
                .addContainerGap())
        );

        Btnkeluar.setText("Keluar");
        Btnkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnkeluarActionPerformed(evt);
            }
        });

        Btnedit.setText("Edit");
        Btnedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtneditActionPerformed(evt);
            }
        });

        Btnsimpan.setText("Simpan");
        Btnsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnsimpanActionPerformed(evt);
            }
        });

        Btntambah.setText("Tambah");
        Btntambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtntambahActionPerformed(evt);
            }
        });

        Btnhapus.setText("Hapus");
        Btnhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnhapusActionPerformed(evt);
            }
        });

        Btnbatal.setText("Batal");
        Btnbatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnbatalActionPerformed(evt);
            }
        });

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel6.setText("Pelayanan Resep ");

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel12.setText("Rawat Jalan");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(PanelRJ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(65, 65, 65)
                                .addComponent(jLabel12))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(129, 129, 129)
                                .addComponent(jLabel6)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Btntambah)
                                    .addComponent(Btnsimpan))
                                .addGap(26, 26, 26)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Btnhapus)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(Btnedit, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(32, 32, 32)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(Btnbatal, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Btnkeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 787, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(388, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(PanelRJ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Btntambah)
                    .addComponent(Btnedit)
                    .addComponent(Btnbatal))
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Btnsimpan)
                    .addComponent(Btnhapus)
                    .addComponent(Btnkeluar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        jTable1.disable();
    }//GEN-LAST:event_jTable1MouseClicked

    private void BtncariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtncariActionPerformed
        // TODO add your handling code here:
        String id_ugd = TFregis.getText();
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
            Statement statement = (Statement) koneksi.createStatement();
            String sql="SELECT * FROM rajal WHERE id_rajal like '"+id_ugd+"'";
            ResultSet rs = statement.executeQuery(sql);
            if (rs.next())
            {
                aktif(true);
                setTombol(false);

                Cbnama.setSelectedItem(rs.getString(2));
                LBtgllahir.setText(rs.getString(3));
                LBdokter.setText(rs.getString(4));
                Cbtindakan.setSelectedItem(rs.getString(5));
                LBtariftindakan.setText(rs.getString(6));
                Cbobat.setSelectedItem(rs.getString(7));
                LBhargaobat.setText(rs.getString(8));
                TFinputresep.setText(rs.getString(9));

                JOptionPane.showMessageDialog(null, "Data ditemukan","Insert Data",JOptionPane.INFORMATION_MESSAGE);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Data tidak ditemukan ","Insert Data",JOptionPane.INFORMATION_MESSAGE);
            }

            koneksi.close();
        }
        catch ( ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException | HeadlessException e)
        {
            JOptionPane.showMessageDialog(null, "Eror:"+e,"Gagal",JOptionPane.WARNING_MESSAGE);
            //System.err.println("Exception: "+e.getMessage());
        }
    }//GEN-LAST:event_BtncariActionPerformed

    private void CbnamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CbnamaActionPerformed
        tampil();
    }//GEN-LAST:event_CbnamaActionPerformed

    private void TFqtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TFqtyActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_TFqtyActionPerformed

    private void CbtindakanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CbtindakanActionPerformed
        // TODO add your handling code here:
        tampil_tindakan();
    }//GEN-LAST:event_CbtindakanActionPerformed

    private void CbobatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CbobatActionPerformed
        // TODO add your handling code here:
        tampil_obat();
    }//GEN-LAST:event_CbobatActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date today = new Date();
        TFinputresep.setText(dateFormat.format(today));
    }//GEN-LAST:event_jButton3ActionPerformed

    private void BtnkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnkeluarActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_BtnkeluarActionPerformed

    private void BtneditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtneditActionPerformed
        // TODO add your handling code here:

        String id_resep = TFregis.getText();
        String tgl_lahir = LBtgllahir.getText();
        String dokter = LBdokter.getText();
        String tarif_tindakan = LBtariftindakan.getText();
        String harga_obat = LBhargaobat.getText();
        String input_resep= TFinputresep.getText();

        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
            Statement statement = (Statement) koneksi.createStatement();
            String sql="UPDATE resep_rj SET id_pasien='"+Cbnama.getSelectedItem()+"',tgl_lahir='"+tgl_lahir+"',id_dokter='"+dokter+"',id_tindakan='"+Cbtindakan.getSelectedItem()+"',harga_tindakan='"+tarif_tindakan+"',id_obat='"+Cbobat.getSelectedItem()+"',harga_obat='"+harga_obat+"',tgl_input_resep='"+input_resep+"' WHERE id_resep LIKE '"+id_resep+"'";
            statement.executeUpdate(sql);
            statement.close();
            JOptionPane.showMessageDialog(null, "Data berhasil diedit..","Insert Data",JOptionPane.INFORMATION_MESSAGE);
            koneksi.close();
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Eror: "+e,"Gagal",JOptionPane.WARNING_MESSAGE);
            //System.err.println("Exception: "+e.getMessage());
        }finally{
            tampilkan_data();
        }
        }

        private void btkeluarActionPerformed(java.awt.event.ActionEvent evt) {
            dispose();
    }//GEN-LAST:event_BtneditActionPerformed

    private void BtnsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnsimpanActionPerformed
        // TODO add your handling code here:

        {
            String id_resep = TFregis.getText();
            String tgl_lahir = LBtgllahir.getText();
            String dokter = LBdokter.getText();
            String tarif_tindakan = LBtariftindakan.getText();
            String harga_obat = LBhargaobat.getText();
            String input_resep= TFinputresep.getText();

            try
            {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
                Statement statement = (Statement) koneksi.createStatement();
                String sql="INSERT INTO resep_rj VALUES('" + id_resep + "','" + Cbnama.getSelectedItem() + "','" + tgl_lahir + "','" + dokter + "','" + Cbtindakan.getSelectedItem() + "','" + tarif_tindakan + "','" + Cbobat.getSelectedItem() + "','" + harga_obat + "','" + input_resep + "')";
                java.sql.PreparedStatement pst = Con.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Data berhasil dimasukkan..","Insert Data",JOptionPane.INFORMATION_MESSAGE);
                aktif(true);

                TFregis.setText("");
                Cbnama.setSelectedItem("-Pilih-");
                LBtgllahir.setText("---------");
                LBdokter.setText("---------");
                Cbtindakan.setSelectedItem("-Pilih-");
                LBtariftindakan.setText("---------");
                Cbobat.setSelectedItem("-Pilih-");
                LBhargaobat.setText("---------");
                TFinputresep.setText("");

            }
            catch (     ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException | HeadlessException e)
            {
                JOptionPane.showMessageDialog(null, "Eror: "+e,"Gagal",JOptionPane.WARNING_MESSAGE);
                //System.err.println("Exception: "+e.getMessage());
            }
            finally {

                tampilkan_data();
            }
        }
    }//GEN-LAST:event_BtnsimpanActionPerformed

    private void BtntambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtntambahActionPerformed
        // TODO add your handling code here:
        aktif(true);
        setTombol(false);
    }//GEN-LAST:event_BtntambahActionPerformed

    private void BtnhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnhapusActionPerformed
        // TODO add your handling code here:
        String id_resep = TFregis.getText();
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
            Statement statement = (Statement) koneksi.createStatement();
            String sql="DELETE FROM resep_rj WHERE id_resep_rj LIKE '"+id_resep+"'";
            statement.executeUpdate(sql);
            statement.close();

            TFregis.setText("");
            Cbnama.setSelectedItem("-Pilih-");
            LBtgllahir.setText("---------");
            LBdokter.setText("---------");
            Cbtindakan.setSelectedItem("-Pilih-");
            LBtariftindakan.setText("---------");
            Cbobat.setSelectedItem("-Pilih-");
            LBhargaobat.setText("---------");
            TFinputresep.setText("");

            JOptionPane.showMessageDialog(null, "Data berhasil dihapus..","Insert Data",JOptionPane.INFORMATION_MESSAGE);
            koneksi.close();
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException | HeadlessException e) { JOptionPane.showMessageDialog(null, "Eror: "+e,"Gagal",JOptionPane.WARNING_MESSAGE);
            //System.err.println("Exception: "+e.getMessage());
        }finally{
            tampilkan_data();
        }
    }//GEN-LAST:event_BtnhapusActionPerformed

    private void BtnbatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnbatalActionPerformed
        // TODO add your handling code here:
        TFregis.setText("");
        Cbnama.setSelectedItem("-Pilih-");
        LBtgllahir.setText("---------");
        LBdokter.setText("---------");
        Cbtindakan.setSelectedItem("-Pilih-");
        LBtariftindakan.setText("---------");
        Cbobat.setSelectedItem("-Pilih-");
        LBhargaobat.setText("---------");
        TFinputresep.setText("");

        aktif(false);
        setTombol(true);
    }//GEN-LAST:event_BtnbatalActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PelayananResepRJ.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PelayananResepRJ.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PelayananResepRJ.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PelayananResepRJ.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PelayananResepRJ().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btnbatal;
    private javax.swing.JButton Btncari;
    private javax.swing.JButton Btnedit;
    private javax.swing.JButton Btnhapus;
    private javax.swing.JButton Btnkeluar;
    private javax.swing.JButton Btnsimpan;
    private javax.swing.JButton Btntambah;
    private javax.swing.JComboBox Cbnama;
    private javax.swing.JComboBox Cbobat;
    private javax.swing.JComboBox Cbtindakan;
    private javax.swing.JLabel LBdokter;
    private javax.swing.JLabel LBhargaobat;
    private javax.swing.JLabel LBpoli;
    private javax.swing.JLabel LBtariftindakan;
    private javax.swing.JLabel LBtgllahir;
    private javax.swing.JPanel PanelRJ;
    private javax.swing.JTextField TFinputresep;
    private javax.swing.JTextField TFqty;
    private javax.swing.JTextField TFregis;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
private void tampilkan_data() {
        
        DefaultTableModel tabelcustom = new DefaultTableModel();
        
        tabelcustom.addColumn("No.RegResep");
        tabelcustom.addColumn("Nama Pasien");
        tabelcustom.addColumn("Tanggal Lahir");
        tabelcustom.addColumn("Nama Dokter");
        tabelcustom.addColumn("Tindakan");
        tabelcustom.addColumn("Harga Tindakan");
        tabelcustom.addColumn("Nama Obat");
        tabelcustom.addColumn("Harga Obat");
        tabelcustom.addColumn("Tanggal Input Resep");
        
        try {
            open_db();
            String sql = " SELECT * FROM resep_rj";
            stm = (Statement) Con.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                
                Object[] x = new Object[9];
                        
                x[0] = rs.getString("id_resep");
                x[1] = rs.getString("id_pasien");
                x[2] = rs.getString("tgl_lahir");
                x[3] = rs.getString("id_dokter");
                x[4] = rs.getString("id_tindakan");
                x[5] = rs.getString("harga_tindakan");
                x[6] = rs.getString("id_obat");
                x[7] = rs.getString("harga_obat");
                x[8] = rs.getString("tgl_input_obat");
                
                
                tabelcustom.addRow(x);
                
            }
           jTable1.setModel(tabelcustom);
        } catch (Exception e) {
        }
    }

    private void open_db() {
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Con = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
            stm = (Statement) Con.createStatement();

        } catch (Exception e){
            JOptionPane.showMessageDialog(null,"Koneksi gagal");
            System.out.println(e.getMessage());
        }
    }
    
    private void aktif(boolean x) {
      Cbnama.setEditable(x);
      Cbtindakan.setEditable(x);
      Cbobat.setEditable(x);
      TFinputresep.setEditable(x);
      TFregis.requestFocus();
    }

    private void setTombol(boolean t) {
     Btntambah.setEnabled(t);
     Btnsimpan.setEnabled(!t);
     Btnhapus.setEnabled(!t);
     Btnedit.setEnabled(!t);
     Btnbatal.setEnabled(!t);
    }

}



