/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programrumahsakit;

import javax.swing.table.DefaultTableModel;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.awt.HeadlessException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.awt.HeadlessException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/**
 *
 * @author THINKPAD
 */
public class RegistrasiRanap extends javax.swing.JFrame {

    private Connection Con;
    private Statement stm;
    private ResultSet rs;
    /**
     * Creates new form RegistrasiRanap
     */
    public RegistrasiRanap() {
        initComponents();
        setLocationRelativeTo(this);
        aktif(false);
        setTombol(true);
        tampil_dokter();
        tampil_kamar();
        tampil();
        tampilkan_data();
        this.setLocationRelativeTo(null);
        
         try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
        Statement statement = (Statement) koneksi.createStatement();
        String sql = "SELECT * from kamar";      
        rs = stm.executeQuery(sql);                               
        
        while(rs.next()){
            int idpoli = Integer.parseInt(rs.getString("id_kamar"));
                Cbkamar.addItem( rs.getString("nama_kamar"));                            
        }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
         try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
        Statement statement = (Statement) koneksi.createStatement();
        String sql = "SELECT * from pasien";      
        rs = stm.executeQuery(sql);                               
        
        while(rs.next()){
            int idpasien = Integer.parseInt(rs.getString("id_pasien"));
                Cbnama.addItem( rs.getString("nama_pasien"));                            
        }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
  
    try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
        Statement statement = (Statement) koneksi.createStatement();
        String sql = "SELECT * from dokter";     
         rs = stm.executeQuery(sql);                               
        
        while(rs.next()){
            int iddokter = Integer.parseInt(rs.getString("id_dokter"));
                Cbdokter.addItem(rs.getString("nama_dokter"));                                 
        }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    
    }
    public void tampil (){
        try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
        Statement statement = (Statement) koneksi.createStatement();
        String sql = "SELECT alamat_pasien, tgl_lahir FROM pasien WHERE nama_pasien='"+Cbnama.getSelectedItem()+"'";  
        ResultSet rs = statement.executeQuery(sql);
        
        while(rs.next()){
            Object[] ob = new Object[3];
            ob[0]=  rs.getString(1);
            ob[1]= rs.getString(2);
            
            
            TAalamat.setText((String)ob[0]);
            TFtgllahir.setText((String)ob[1]);
        }
        rs.close(); stm.close();
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        {
            
        }
 }
    public void tampil_dokter (){
        try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
        Statement statement = (Statement) koneksi.createStatement();
        String sql = "SELECT tipe_dokter FROM dokter WHERE nama_dokter='"+Cbdokter.getSelectedItem()+"'";  
        ResultSet rs = statement.executeQuery(sql);
        
        while(rs.next()){
            Object[] ob = new Object[2];
            ob[0]=  rs.getString(1);
            
            
            
           LBtipedokter.setText((String)ob[0]);
           
        }
        rs.close(); stm.close();
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } 
    }public void tampil_kamar (){
        try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
        Statement statement = (Statement) koneksi.createStatement();
        String sql = "SELECT tipe_kamar FROM kamar WHERE nama_kamar='"+Cbkamar.getSelectedItem()+"'";  
        ResultSet rs = statement.executeQuery(sql);
        
        while(rs.next()){
            Object[] ob = new Object[2];
            ob[0]=  rs.getString(1);
            
            
            
           LBtipekamar.setText((String)ob[0]);
           
        }
        rs.close(); stm.close();
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } 
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TFdatang = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        TFpulang = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        Btnedit = new javax.swing.JButton();
        Btntambah = new javax.swing.JButton();
        Cbkamar = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        LBtipedokter = new javax.swing.JLabel();
        TFregis = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        TAalamat = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        Cbnama = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        Btncari = new javax.swing.JButton();
        TFtgllahir = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        Cbdokter = new javax.swing.JComboBox();
        jLabel9 = new javax.swing.JLabel();
        Btnsimpan = new javax.swing.JButton();
        Btnhapus = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Btnbatal = new javax.swing.JButton();
        Btnkeluar = new javax.swing.JButton();
        LBtipekamar = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel6.setText("Check-IN");

        jLabel7.setText("Check-OUT");

        Btnedit.setText("Edit");
        Btnedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtneditActionPerformed(evt);
            }
        });

        Btntambah.setText("Tambah");
        Btntambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtntambahActionPerformed(evt);
            }
        });

        Cbkamar.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-Pilih-" }));
        Cbkamar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CbkamarActionPerformed(evt);
            }
        });

        jLabel3.setText("Kamar");

        LBtipedokter.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        LBtipedokter.setText("-------------");

        TAalamat.setColumns(20);
        TAalamat.setRows(5);
        jScrollPane1.setViewportView(TAalamat);

        jLabel10.setText("No.registrasi");

        Cbnama.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-Pilih-" }));
        Cbnama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CbnamaActionPerformed(evt);
            }
        });

        jLabel4.setText("Tgl lahir");

        Btncari.setText("Cari");
        Btncari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtncariActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("PMingLiU-ExtB", 3, 14)); // NOI18N
        jLabel5.setText("REGISTRASI RAWAT INAP");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        jLabel8.setText("Tipe Dokter");

        Cbdokter.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-Pilih-" }));
        Cbdokter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CbdokterActionPerformed(evt);
            }
        });

        jLabel9.setText("Dokter");

        Btnsimpan.setText("Simpan");
        Btnsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnsimpanActionPerformed(evt);
            }
        });

        Btnhapus.setText("Hapus");
        Btnhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnhapusActionPerformed(evt);
            }
        });

        jLabel1.setText("Nama Pasien");

        jLabel2.setText("Alamat");

        Btnbatal.setText("Batal");
        Btnbatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnbatalActionPerformed(evt);
            }
        });

        Btnkeluar.setText("Keluar");
        Btnkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnkeluarActionPerformed(evt);
            }
        });

        LBtipekamar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        LBtipekamar.setText("-------");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(31, 31, 31)
                                .addComponent(TFtgllahir, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(27, 27, 27)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(LBtipedokter)
                                    .addComponent(Cbdokter, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(61, 61, 61)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel6))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(TFdatang)
                            .addComponent(TFpulang, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2))
                                .addGap(33, 33, 33)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Cbnama, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(99, 99, 99)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Btntambah)
                                    .addComponent(Btnsimpan))
                                .addGap(26, 26, 26)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Btnhapus)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(Btnedit, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(32, 32, 32)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(Btnbatal, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Btnkeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addGap(33, 33, 33)
                                        .addComponent(TFregis, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(33, 33, 33)
                                        .addComponent(Cbkamar, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(39, 39, 39)
                                        .addComponent(Btncari))
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(LBtipekamar)))
                                .addGap(55, 55, 55)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TFregis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10)
                            .addComponent(Btncari))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(Cbkamar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LBtipekamar))
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(Cbnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Btntambah)
                            .addComponent(Btnedit)
                            .addComponent(Btnbatal))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Btnsimpan)
                            .addComponent(Btnhapus)
                            .addComponent(Btnkeluar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(TFdatang, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(TFtgllahir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Cbdokter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TFpulang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(LBtipedokter))
                .addGap(55, 55, 55)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtneditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtneditActionPerformed
        // TODO add your handling code here:

        String id_ranap = TFregis.getText();
        String tipe_kamar = LBtipekamar.getText();
        String alamat = TAalamat.getText();
        String tgl_lahir = TFtgllahir.getText();
        String tipe_dokter = LBtipedokter.getText();
        String datang = TFdatang.getText();
        String pulang = TFpulang.getText();

        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
            Statement statement = (Statement) koneksi.createStatement();
            String sql="UPDATE ranap SET id_kamar='"+Cbkamar.getSelectedItem()+"',tipe_kamar='"+LBtipekamar.getText()+"',id_pasien='"+Cbnama.getSelectedItem()+"',alamat='"+alamat+"',tgl_lahir='"+tgl_lahir+"',tipe_dokter='"+tipe_dokter+"',id_dokter='"+Cbdokter.getSelectedItem()+"',tgl_datang='"+datang+"',tgl_pulang='"+pulang+"' WHERE id_ranap LIKE '"+id_ranap+"'";
            statement.executeUpdate(sql);
            statement.close();
            JOptionPane.showMessageDialog(null, "Data berhasil diedit..","Insert Data",JOptionPane.INFORMATION_MESSAGE);
            koneksi.close();
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Eror: "+e,"Gagal",JOptionPane.WARNING_MESSAGE);
            //System.err.println("Exception: "+e.getMessage());
        }finally{
            tampilkan_data();
        }
        
        }

        private void btkeluarActionPerformed(java.awt.event.ActionEvent evt) {
            dispose();
    }//GEN-LAST:event_BtneditActionPerformed

    private void BtntambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtntambahActionPerformed
        // TODO add your handling code here:
        aktif(true);
        setTombol(false);
    }//GEN-LAST:event_BtntambahActionPerformed

    private void CbkamarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CbkamarActionPerformed
        // TODO add your handling code here:
        tampil_kamar();
    }//GEN-LAST:event_CbkamarActionPerformed

    private void CbnamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CbnamaActionPerformed
        tampil();
    }//GEN-LAST:event_CbnamaActionPerformed

    private void BtncariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtncariActionPerformed
        // TODO add your handling code here:
        String id_ranap = TFregis.getText();
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
            Statement statement = (Statement) koneksi.createStatement();
            String sql="SELECT * FROM ranap WHERE id_ranap like '"+id_ranap+"'";
            ResultSet rs = statement.executeQuery(sql);
            if (rs.next())
            {
                aktif(true);
                setTombol(false);
                Cbkamar.setSelectedItem(rs.getString(2));
                LBtipekamar.setText(rs.getString(3));
                Cbnama.setSelectedItem(rs.getString(4));
                TAalamat.setText(rs.getString(5));
                TFtgllahir.setText(rs.getString(6));
                Cbdokter.setSelectedItem(rs.getString(7));
                LBtipedokter.setText(rs.getString(8));
                TFdatang.setText(rs.getString(9));
                TFpulang.setText(rs.getString(10));

                JOptionPane.showMessageDialog(null, "Data ditemukan","Insert Data",JOptionPane.INFORMATION_MESSAGE);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Data tidak ditemukan ","Insert Data",JOptionPane.INFORMATION_MESSAGE);
            }

            koneksi.close();
        }
        catch ( ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException | HeadlessException e)
        {
            JOptionPane.showMessageDialog(null, "Eror:"+e,"Gagal",JOptionPane.WARNING_MESSAGE);
            //System.err.println("Exception: "+e.getMessage());
        }
    }//GEN-LAST:event_BtncariActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        jTable1.disable();
    }//GEN-LAST:event_jTable1MouseClicked

    private void CbdokterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CbdokterActionPerformed
        tampil_dokter();
    }//GEN-LAST:event_CbdokterActionPerformed

    private void BtnsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnsimpanActionPerformed
        // TODO add your handling code here:

        {
            String id_ranap = TFregis.getText();
            String tipe_kamar = LBtipekamar.getText();
            String alamat = TAalamat.getText();
            String tgl_lahir = TFtgllahir.getText();
            String tipe_dokter = LBtipedokter.getText();
            String datang = TFdatang.getText();
            String pulang = TFpulang.getText();

            try
            {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
                Statement statement = (Statement) koneksi.createStatement();
                String sql="INSERT INTO ranap VALUES('" + id_ranap + "','" + Cbkamar.getSelectedItem() +"','" + tipe_kamar + "','" + Cbnama.getSelectedItem() + "','" + alamat + "','" + tgl_lahir + "','" + Cbdokter.getSelectedItem() + "','" + tipe_dokter + "','" + datang + "','" + pulang + "')";
                java.sql.PreparedStatement pst = Con.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Data berhasil dimasukkan..","Insert Data",JOptionPane.INFORMATION_MESSAGE);
                aktif(true);
                TFregis.setText("");
                Cbkamar.setSelectedItem("-Pilih-");
                LBtipekamar.setText("-----");
                Cbnama.setSelectedItem("-Pilih-");
                TAalamat.setText("");
                TFtgllahir.setText("");
                LBtipedokter.setText("--------");
                Cbdokter.setSelectedItem("");
                TFdatang.setText("");
                TFpulang.setText("");

            }
            catch (     ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException | HeadlessException e)
            {
                JOptionPane.showMessageDialog(null, "Eror: "+e,"Gagal",JOptionPane.WARNING_MESSAGE);
                //System.err.println("Exception: "+e.getMessage());
            }
            finally {

                tampilkan_data();
            }
        }
    }//GEN-LAST:event_BtnsimpanActionPerformed

    private void BtnhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnhapusActionPerformed
        // TODO add your handling code here:
        String id_ranap = TFregis.getText();
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection koneksi = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
            Statement statement = (Statement) koneksi.createStatement();
            String sql="DELETE FROM ranap WHERE id_ranap LIKE '"+id_ranap+"'";
            statement.executeUpdate(sql);
            statement.close();

            TFregis.setText("");
            Cbkamar.setSelectedItem("-Pilih-");
            LBtipekamar.setText("------");
            Cbnama.setSelectedItem("-Pilih-");
            TAalamat.setText("");
            TFtgllahir.setText("");
            LBtipedokter.setText("--------");
            Cbdokter.setSelectedItem("-Pilih-");
            TFdatang.setText("");
            TFpulang.setText("");

            JOptionPane.showMessageDialog(null, "Data berhasil dihapus..","Insert Data",JOptionPane.INFORMATION_MESSAGE);
            koneksi.close();
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException | HeadlessException e) { JOptionPane.showMessageDialog(null, "Eror: "+e,"Gagal",JOptionPane.WARNING_MESSAGE);
            //System.err.println("Exception: "+e.getMessage());
        }finally{
            tampilkan_data();
        }
    }//GEN-LAST:event_BtnhapusActionPerformed

    private void BtnbatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnbatalActionPerformed
        // TODO add your handling code here:
        TFregis.setText("");
        Cbkamar.setSelectedItem("-Pilih-");
        LBtipekamar.setText("-----");
        Cbnama.setSelectedItem("-Pilih-");
        TAalamat.setText("");
        TFtgllahir.setText("");
        LBtipedokter.setText("--------");
        Cbdokter.setSelectedItem("-Pilih-");
        TFdatang.setText("");
        TFpulang.setText("");

        aktif(false);
        setTombol(true);
    }//GEN-LAST:event_BtnbatalActionPerformed

    private void BtnkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnkeluarActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_BtnkeluarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistrasiRanap.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistrasiRanap.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistrasiRanap.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistrasiRanap.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistrasiRanap().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btnbatal;
    private javax.swing.JButton Btncari;
    private javax.swing.JButton Btnedit;
    private javax.swing.JButton Btnhapus;
    private javax.swing.JButton Btnkeluar;
    private javax.swing.JButton Btnsimpan;
    private javax.swing.JButton Btntambah;
    private javax.swing.JComboBox Cbdokter;
    private javax.swing.JComboBox Cbkamar;
    private javax.swing.JComboBox Cbnama;
    private javax.swing.JLabel LBtipedokter;
    private javax.swing.JLabel LBtipekamar;
    private javax.swing.JTextArea TAalamat;
    private javax.swing.JTextField TFdatang;
    private javax.swing.JTextField TFpulang;
    private javax.swing.JTextField TFregis;
    private javax.swing.JTextField TFtgllahir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
  private void tampilkan_data() {
        
        DefaultTableModel tabelcustom = new DefaultTableModel();
        
        tabelcustom.addColumn("No.RegRanap");
        tabelcustom.addColumn("Kamar");
        tabelcustom.addColumn("Tipe Kamar");
        tabelcustom.addColumn("Nama Pasien");
        tabelcustom.addColumn("Alamat");
        tabelcustom.addColumn("Tanggal Lahir");
        tabelcustom.addColumn("Nama Dokter");
        tabelcustom.addColumn("Spesialis");
        tabelcustom.addColumn("Tanggal Datang");
        tabelcustom.addColumn("Tanggal Pulang");
        
        try {
            open_db();
            String sql = " SELECT * FROM ranap";
            stm = (Statement) Con.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                
                Object[] x = new Object[10];
                        
                x[0] = rs.getString("id_ranap");
                x[1] = rs.getString("id_kamar");
                x[2] = rs.getString("tipe_kamar");
                x[3] = rs.getString("id_pasien");
                x[4] = rs.getString("alamat");
                x[5] = rs.getString("tgl_lahir");
                x[6] = rs.getString("id_dokter");
                x[7] = rs.getString("tipe_dokter");
                x[8] = rs.getString("cekin");
                x[9] = rs.getString("cekout");
                
                
                tabelcustom.addRow(x);
                
            }
           jTable1.setModel(tabelcustom);
        } catch (Exception e) {
        }
    }

    private void open_db() {
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Con = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/simrs", "root", "");
            stm = (Statement) Con.createStatement();

        } catch (Exception e){
            JOptionPane.showMessageDialog(null,"Koneksi gagal");
            System.out.println(e.getMessage());
        }
    }
    
    private void aktif(boolean x) {
      Cbkamar.setEditable(x);
      Cbnama.setEditable(x);
      TAalamat.setEditable(x);
      TFtgllahir.setEditable(x);
      Cbdokter.setEditable(x);
      TFpulang.setEditable(x);
      TFdatang.setEditable(x);
      TFregis.requestFocus();
    }

    private void setTombol(boolean t) {
     Btntambah.setEnabled(t);
     Btnsimpan.setEnabled(!t);
     Btnhapus.setEnabled(!t);
     Btnedit.setEnabled(!t);
     Btnbatal.setEnabled(!t);
    }

}
