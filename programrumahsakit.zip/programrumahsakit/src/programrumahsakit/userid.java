/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programrumahsakit;

/**
 *
 * @author THINKPAD
 */
public class userid {
    private static String TFuser;
    
    public static void setUserLogin(String txtuser) {
userid.TFuser = TFuser;
}
public static String getUserLogin() {
return TFuser;
}
}
